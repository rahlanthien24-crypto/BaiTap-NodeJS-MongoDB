# BÀI TẬP 3: QUẢN LÝ NHÀ HÀNG BẰNG NODE.JS VÀ MONGODB

**Sinh viên:** Rah Lan Thiên  
**Môn học:** Node.js và MongoDB  
**Chủ đề:** Quản lý danh sách món ăn trong nhà hàng

## Mục tiêu
Sử dụng Node.js kết nối MongoDB và thực hành các thao tác cơ bản trong Bài 3.

## Chức năng
1. Kết nối cơ sở dữ liệu `QuanLyNhaHang`, collection `monan`.
2. Thêm 5 món ăn mẫu (không tạo bản ghi trùng khi chạy lại).
3. Hiển thị tất cả món ăn (`find`).
4. Lọc món ăn có giá dưới 50.000đ (`$lt`).
5. Cập nhật giá món MA01 thành 60.000đ (`updateOne`, `$set`).
6. Xóa món MA05 (`deleteOne`).
7. Sắp xếp theo giá tăng dần (`sort`).
8. Đếm số món còn lại (`countDocuments`).

## Cấu trúc dữ liệu
Mỗi món gồm: `maMon`, `tenMon`, `loai`, `gia`.

| Mã | Tên món | Loại | Giá mẫu (VNĐ) |
|---|---|---|---:|
| MA01 | Cơm chiên hải sản | Món chính | 55.000 |
| MA02 | Phở bò | Món chính | 45.000 |
| MA03 | Gỏi cuốn | Khai vị | 30.000 |
| MA04 | Lẩu thái | Món chính | 180.000 |
| MA05 | Nước cam | Đồ uống | 25.000 |

## Cách chạy trên VS Code
1. Cài Node.js và MongoDB Community Server; đảm bảo MongoDB đang chạy ở `127.0.0.1:27017`.
2. Mở đúng thư mục dự án trong VS Code (File → Open Folder).
3. Mở Terminal và chạy:

```powershell
npm install
npm start
```

Hoặc dùng `node app.js` sau khi cài thư viện.

## Kết quả mong đợi
Terminal in danh sách 5 món, danh sách món dưới 50.000đ, thông báo cập nhật/xóa, bảng giá tăng dần và tổng số món còn lại.

**Lưu ý:** Khi chạy lại, món MA05 sẽ được thêm lại vì chương trình chuẩn bị dữ liệu mẫu nếu thiếu; dữ liệu mẫu của các món đã có không bị ghi đè (ngoại trừ bước cập nhật MA01). Đây là chương trình chạy trên Terminal, không có giao diện web.

## Nộp GitHub
Đưa `app.js`, `package.json`, `README.md`, `.gitignore` lên repository. Không tải thư mục `node_modules` lên.
