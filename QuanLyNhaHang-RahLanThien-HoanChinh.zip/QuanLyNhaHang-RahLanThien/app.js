// Bài 3 - Quản lý nhà hàng - Sinh viên: Rah Lan Thiên
const { MongoClient } = require('mongodb');

const client = new MongoClient('mongodb://127.0.0.1:27017');
const dbName = 'QuanLyNhaHang';

async function main() {
  try {
    await client.connect();
    console.log('Kết nối MongoDB thành công!');
    const db = client.db(dbName);
    const monAn = db.collection('monan');

    // Tạo dữ liệu mẫu nếu chưa có (chạy lại không thêm trùng)
    const duLieuMau = [
      { maMon: 'MA01', tenMon: 'Cơm chiên hải sản', loai: 'Món chính', gia: 55000 },
      { maMon: 'MA02', tenMon: 'Phở bò', loai: 'Món chính', gia: 45000 },
      { maMon: 'MA03', tenMon: 'Gỏi cuốn', loai: 'Khai vị', gia: 30000 },
      { maMon: 'MA04', tenMon: 'Lẩu thái', loai: 'Món chính', gia: 180000 },
      { maMon: 'MA05', tenMon: 'Nước cam', loai: 'Đồ uống', gia: 25000 }
    ];
    await monAn.createIndex({ maMon: 1 }, { unique: true });
    for (const mon of duLieuMau) {
      await monAn.updateOne({ maMon: mon.maMon }, { $setOnInsert: mon }, { upsert: true });
    }
    console.log('\n1. Đã chuẩn bị dữ liệu 5 món ăn mẫu.');

    const hienThi = async (tieuDe, cursor) => {
      console.log(`\n${tieuDe}`);
      console.table(await cursor.project({ _id: 0 }).toArray());
    };

    // 2. Hiển thị tất cả món ăn
    await hienThi('2. DANH SÁCH MÓN ĂN:', monAn.find());

    // 3. Tìm món ăn có giá dưới 50.000đ
    await hienThi('3. MÓN ĂN CÓ GIÁ DƯỚI 50.000đ:', monAn.find({ gia: { $lt: 50000 } }));

    // 4. Cập nhật giá món MA01
    const capNhat = await monAn.updateOne({ maMon: 'MA01' }, { $set: { gia: 60000 } });
    console.log(`\n4. Cập nhật MA01: ${capNhat.matchedCount ? 'thành công' : 'không tìm thấy'}`);

    // 5. Xóa món MA05
    const xoa = await monAn.deleteOne({ maMon: 'MA05' });
    console.log(`5. Xóa MA05: ${xoa.deletedCount ? 'thành công' : 'không tìm thấy'}`);

    // 6. Sắp xếp giá tăng dần
    await hienThi('6. DANH SÁCH THEO GIÁ TĂNG DẦN:', monAn.find().sort({ gia: 1 }));

    // 7. Thống kê số món còn lại
    console.log(`\n7. Tổng số món hiện có: ${await monAn.countDocuments()}`);
  } catch (err) {
    console.error('Lỗi:', err.message);
    process.exitCode = 1;
  } finally {
    await client.close();
  }
}

main();
